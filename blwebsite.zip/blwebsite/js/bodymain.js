var animation = bodymovin.loadAnimation({
    container: document.getElementById('bg2'),
    renderer: 'html',
    loop: true,
    autoplay: true,
    path: '../js/data.json'
})